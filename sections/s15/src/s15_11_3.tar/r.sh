#!/bin/bash

PAPER=mironovich
if [[ "$1" == "clean" ]]
then
    echo "Cleaning paper $PAPER"
    rm -f $PAPER.pdf *.sty *.bst *.aux *.toc *.blg *.bbl *.log *.out pic/*-converted-to.pdf
    rm -f pic/*.{1,2,3,4,5,6,7,8,9,10} pic/*.log pic/*.mpx
else
    echo "Compiling paper $PAPER"
    
    pdflatex $PAPER
    pdflatex $PAPER 

    echo "======================"
    echo "Word count in abstract: `cat $PAPER.tex | sed '1,/begin{abstract}/d;/end{abstract}/,$d' | wc -w`"
    echo "Unfinished TODOs: `cat $PAPER.tex | grep "TODO" | wc -l`"  
fi
